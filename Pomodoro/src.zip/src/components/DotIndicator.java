package components;

import javax.swing.ImageIcon;

public abstract class DotIndicator {
	public abstract ImageIcon getImageIcon();
}
