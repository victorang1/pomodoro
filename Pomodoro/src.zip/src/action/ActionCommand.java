package action;

public interface ActionCommand {
    public void execute();
}
