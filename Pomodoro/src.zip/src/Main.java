import GUI.GUIPomodoro;

public class Main {

	public Main() {
		GUIPomodoro.getInstance();
	}

	public static void main(String[] args) {
		new Main();
	}
}
