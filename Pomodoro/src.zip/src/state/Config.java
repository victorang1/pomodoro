package state;

public class Config {

	public static final int WORK_TIME = 5;
    public static final int BREAK_TIME =2;
    public static final int LONG_BREAK =2;
    
    public static final String LOG_PATH = "log.csv";
}
