package state.buttonstate;

public abstract class ActionButtonState {
    
    public abstract ActionButtonState switchState();
}
