package event;

public interface Observer {
    public void update();
}
